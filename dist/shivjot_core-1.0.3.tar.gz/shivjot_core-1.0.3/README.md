# Shivjot-Core

High-performance Python utilities for AI/ML workflows, computer vision, and enhanced Pandas/NumPy data engineering.

## Installation
```bash
pip install shivjot-core

Markdown
# Shivjot-Core

High-performance Python utilities for AI/ML workflows, computer vision, and enhanced Pandas/NumPy data engineering.

## Installation
```bash
pip install shivjot-core
Features
AI Analysis: Custom Pandas accessor for rapid data insights.

Image Processing: Tools for frequency domain transformations.

Optimized Performance: Built on top of NumPy and Pandas.

About the Author
Created by Shivjot Choudhary.

Portfolio - https://shivjotchoudhary.github.io/

GitHub - https://github.com/ShivjotChoudhary
